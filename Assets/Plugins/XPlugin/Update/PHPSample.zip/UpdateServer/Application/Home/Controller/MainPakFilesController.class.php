<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-12
 * Time: 下午4:25
 */

namespace Home\Controller;


use Home\Model\MainPakFilesModel;
use Think\Controller;

class MainPakFilesController extends BaseController
{
    public $URLBase = '/Uploads/MainPaks/';
    public $UploadDir = './Uploads/MainPaks/';

    public function __construct()
    {
        parent::__construct();
        $this->assign('active', 'main');
        $this->assign('tab', 'file');
    }

    public function index()
    {
        $mainPakFilesModel = new MainPakFilesModel();
        $files = $mainPakFilesModel->order('time desc')->select();
        foreach ($files as &$f) {
            $f['url'] = SITE_URL . $this->URLBase . $f['file_location'];
        }
        $this->assign('files', $files);

        $this->display();
    }

    public function delete($id)
    {
        $this->error('删除暂时不可用', '', 1);
//        $this->redirect('index');
    }

    public function showUpload()
    {
        $this->display('upload');
    }

    public function upload()
    {
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize = 1073741824;// 设置附件上传大小
        $upload->rootPath = $this->UploadDir; // 设置附件上传根目录
        $upload->autoSub = false;
        // 上传文件
        $info = $upload->upload();
        if ($info) {// 上传错误提示错误信息
            $file = $info['file'];
            $location = $file['name'];
            rename($this->UploadDir . $file['savename'], $this->UploadDir . $location);

            $data['file_name'] = $file['name'];
            $data['file_location'] = $location;
            $mainPakFilesModel = new MainPakFilesModel();
            $result = $mainPakFilesModel->add($data);
            if ($result) {
                $this->redirect('index');
            } else {
                $this->error($result);
            }
        } else {// 上传成功
            $this->error($upload->getError());
        }
    }

}