<?php
namespace Home\Controller;

class IndexController extends BaseController
{
    public function __construct(){
        parent::__construct();
        $this->assign('active', 'home');
    }

    public function index()
    {
        $this->assign('checkUpdateURL',SITE_URL.'/index.php/WebAPI/CheckUpdate');
        $this->display();
    }

}