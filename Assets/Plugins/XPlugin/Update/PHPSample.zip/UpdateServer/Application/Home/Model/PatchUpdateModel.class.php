<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-6
 * Time: 下午7:31
 */

namespace Home\Model;


use Think\Model;

class PatchUpdateModel extends Model
{

    public function LastPatchUpdate($mainVersion)
    {
        $result = $this->where(array('main_version' => $mainVersion))->order('patch_version desc')->find();
        return $result;
    }

    public function LastEnablePatchUpdateWithPerm($mainVersion,$permission)
    {
        $releaseStateMode = new ReleaseStateModel();
        $permission = $releaseStateMode->GetPermission($permission);

        $where['enable'] = true;
        $where['permission'] = array('elt', $permission);
        $where['main_version']=$mainVersion;

        return $this->join('release_state on patch_update.release_state=release_state.name')
            ->where($where)->order('patch_version desc')->find();
    }

    public function SelectByMainVersion($mainVersion, $notEnabled)
    {
        $where['main_version'] = $mainVersion;
        if ($notEnabled) {
            $where['enable'] = 1;
        }
        $result = $this->where($where)->order('patch_version desc')->select();
        return $result;
    }


    public function FindAllWithLimit($limit)
    {
        $result = $this->order('main_version desc,patch_version desc')->limit($limit)->select();
        return $result;
    }


    public function SelectBetween($mainVersion, $minPatchVersion, $maxPatchVersion)
    {
        $where['main_version'] = array('eq', $mainVersion);
        $where['patch_version'] = array(array('gt', $minPatchVersion), array('elt', $maxPatchVersion));
        $ret = $this->where($where)->select();
        return $ret;
    }


}