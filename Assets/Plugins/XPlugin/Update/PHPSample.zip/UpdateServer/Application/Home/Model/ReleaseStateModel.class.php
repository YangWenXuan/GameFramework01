<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-5
 * Time: 下午12:08
 */

namespace Home\Model;

use Think\Model;

class ReleaseStateModel extends Model
{

    public function AllReleaseState()
    {
        return $this->select();
    }

    public function GetPermission($state){
        $all=$this->AllReleaseState();
        foreach($all as $s){
            if($s['name']==$state){
                return $s['permission'];
            }
        }
    }

}