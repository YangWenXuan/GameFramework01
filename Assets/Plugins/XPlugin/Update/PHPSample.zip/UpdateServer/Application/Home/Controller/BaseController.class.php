<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-7-14
 * Time: 下午6:01
 */

namespace Home\Controller;


use Think\Controller;

class BaseController extends  Controller
{

    public function __construct()
    {
        parent::__construct();

        if(INIT){
            $this->redirect('OutOfBox/index');
            return;
        }
        $this->assign('site_name',SITE_NAME);
        $this->checkLogin();
    }



    private  function checkLogin(){
        $this->_admininfo = session('admin');
        if(empty($this->_admininfo)){
            $this->redirect(MODULE_NAME.'/Login/Login');
        }
    }

}