<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-11
 * Time: 下午8:15
 */

namespace Home\Model;


use Think\Model;

class PermissionModel extends Model
{


}