<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-11
 * Time: 下午8:07
 */

namespace Home\Controller;


use Home\Model\PermissionModel;
use Home\Model\ReleaseStateModel;

class PermissionController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->assign('active', 'permission');
    }

    public function index()
    {

        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);


        $permissionModel = new PermissionModel();
        $data = $permissionModel->select();

        $this->assign('data', $data);
        $this->display('index');
    }

    public function showAdd()
    {
        $this->assign('type', 'add');
        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);

        $this->display('show');
    }

    public function add()
    {
        $user = I('post.user', '', 'trim');
        $permission = I('post.permission', '', 'trim');
        $description = I('post.description', '', 'trim');

        $data['user'] = $user;
        $data['permission'] = $permission;
        $data['description'] = $description;

        $permissionModel = new PermissionModel();
        $result = $permissionModel->add($data);
        if ($result) {
            $this->redirect('index');
        } else {
            echo 'error';
        }
    }

    public function showUpdate($user)
    {
        $this->assign('type', 'update');

        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);


        $permissionModel = new PermissionModel();
        $data = $permissionModel->where(array('user' => $user))->find();
        $this->assign('data', $data);

        $this->display('show');
    }

    public function update()
    {
        $user = I('post.user', '', 'trim');
        $permission = I('post.permission', '', 'trim');
        $description = I('post.description', '', 'trim');

        $data['permission'] = $permission;
        $data['description'] = $description;

        $permissionModel = new PermissionModel();
        $result = $permissionModel->where(array('user' => $user))->setField($data);
        if ($result!==false) {
            $this->redirect('index');
        } else {
            $this->error($result);
        }
    }

    public function delete($user)
    {
        $permissionModel = new PermissionModel();
        $data = $permissionModel->where(array('user' => $user))->delete();
        if (!$data) {
            $this->error('删除出错', 'index', 1);
            return;
        }
        $this->redirect('index');

    }


}