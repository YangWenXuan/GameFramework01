<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-6
 * Time: 下午3:07
 */

namespace Home\Controller;


use Home\Model\MainUpdateModel;
use Home\Model\PatchFilesModel;
use Home\Model\PatchUpdateModel;
use Home\Model\PermissionModel;
use Home\Model\ReleaseStateModel;
use Think\Controller;

class WebAPIController extends Controller
{
    public $urlBase = SITE_URL.'/Uploads/Patches/{0}-{1}';
    public $fileConflictInfo = '检测到文件冲突，需要更新';

    public function __construct()
    {
        parent::__construct();
    }

    public function CheckUpdate()
    {
        $clientData = json_decode($_POST['Data'], true);

        $user = $clientData['User'];
        if ($user != null) {
            $permissionModel = new PermissionModel();
            $permissionData = $permissionModel->where(array('user' => $user))->find();
            if ($permissionData != null) {
                $permission = $permissionData['permission'];
            }
        }
        if (!isset($permission)) {
            $permission = "RTM";
        }

        $mainVersion = $clientData['Version'];

        $mainUpdateModel = new MainUpdateModel();
        $lastMainRelease = $mainUpdateModel->LastEnableReleaseWithPerm($permission);

        $lastMainVersion = $lastMainRelease['version'];
        if ($lastMainVersion > $mainVersion) {//检测到完整更新
            $ret = array('Type' => 1, 'Version' => $lastMainVersion, 'URL' => $lastMainRelease['url'], 'Info' => $lastMainRelease['info']);
            echo json_encode($ret);
            return;
        }
        //没有完整更新，开始检查补丁更新
        $clientPatchVersion = $clientData['PatchVersion'];

        $patchUpdateModel = new PatchUpdateModel();
        $lastPatchUpdate = $patchUpdateModel->LastEnablePatchUpdateWithPerm($lastMainVersion, $permission);

        if ($lastPatchUpdate == null || $lastPatchUpdate['patch_version'] <= $clientPatchVersion) {//没有补丁更新
            $ret = array('Type' => 0, 'PatchVersion' => $clientPatchVersion, 'URL' => $this->urlBase, "Info" => $this->fileConflictInfo);
            echo json_encode($ret);
            return;
        }
        //有补丁更新，开始处理
        $lastPatchVersion = $lastPatchUpdate['patch_version'];

        $diffPatches = $patchUpdateModel->SelectBetween($lastMainVersion, $clientPatchVersion, $lastPatchVersion);
        $ids = array();
        foreach ($diffPatches as $patch) {
            array_push($ids, $patch['id']);
        }

        $patchFilesModel = new PatchFilesModel();
        $files = $patchFilesModel->SelectByPatchId($ids);

        //过滤files中的文件，对于同名文件，只保留最新的
        $filterFiles = array();
        foreach ($files as $f) {
            $find = false;
            $i = 0;
            foreach ($filterFiles as $filter) {
                if ($filter['file_name'] == $f['file_name']) {
                    $find = true;
                    if ($filter['version'] < $f['version']) {
                        $filterFiles[$i] = $f;
                        break;
                    }
                }
                $i++;
            }
            if (!$find) {
                array_push($filterFiles, $f);
            }
        }

        $ret["Type"] = 2;
        $ret["PatchVersion"] = $lastPatchVersion;
        $ret['URL'] = $this->urlBase;
        $ret['Info'] = $lastPatchUpdate['info'];
        $patches = array();
        foreach ($filterFiles as $file) {
            $patches[$file['file_name']] = array('Version' => $file['version'], 'Size' => $file['size'], 'MD5' => $file['md5']);
        }
        $ret['Patches'] = $patches;

        echo json_encode($ret);

        return;


    }

}