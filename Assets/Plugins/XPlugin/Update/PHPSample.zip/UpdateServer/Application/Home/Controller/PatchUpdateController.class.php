<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-7-19
 * Time: 下午6:23
 */

namespace Home\Controller;


use Home\Model\PatchFilesModel;
use Home\Model\PatchUpdateModel;
use Home\Model\ReleaseStateModel;
use Home\Model\MainUpdateModel;

class PatchUpdateController extends BaseController
{

    public $PatchDir = './Uploads/Patches/';

    public function __construct()
    {
        parent::__construct();
        $this->assign('active', 'patch');
    }


    public function  index()
    {
        $model = new PatchUpdateModel();
        $data = $model->FindAllWithLimit(200);

        $updates = array();
        foreach ($data as $d) {
            $mainVersion = $d['main_version'];
            if (array_key_exists($mainVersion, $updates)) {
                array_push($updates[$mainVersion], $d);
            } else {
                $updates[$mainVersion] = array($d);
            }
        }

        $this->assign('updates', $updates);
        $this->display();
    }

    public function showAdd()
    {
        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);

        $mainUpdateModel = new MainUpdateModel();
        $lastMainUpdate = $mainUpdateModel->LastEnableRelease();
        if(!$lastMainUpdate){
            $this->error('请先添加一个完整更新');
            return;
        }
        $this->assign('lastMainUpdate', $lastMainUpdate);

        $patchUpdateModel = new PatchUpdateModel();
        $allEnablePatchUpdate = $patchUpdateModel->SelectByMainVersion($lastMainUpdate['version'], true);

        $ids = array();
        foreach ($allEnablePatchUpdate as $patch) {
            array_push($ids, $patch['id']);
        }

        $patchFilesModel = new PatchFilesModel();
        $patchFiles = $patchFilesModel->SelectByPatchId($ids);
        $files = array();
        foreach ($patchFiles as $patchFile) {
            $fileName = $patchFile['file_name'];
            if (array_key_exists($fileName, $files)) {
                if ($files[$fileName]['version'] < $patchFile['version']) {
                    $files[$fileName] = $patchFile;
                }
            } else {
                $files[$fileName] = $patchFile;
            }
        }
        foreach ($files as $f) {
            if ($f['to_delete'] == true) {
                unset($files[$f['file_name']]);
            }
        }

        $this->assign('filesCanDelete', $files);

        $this->display('showAdd');
    }


    public function add()
    {
        $deleteGroup = $_POST['deleteGroup'];
        $haveUploadFile = !empty($_FILES['file']['name'][0]);
        $haveDeleteFile = !empty($deleteGroup);
        if (!$haveUploadFile && !$haveDeleteFile) {
            $this->error('没有更新文件或删除文件', '', 1);
            return;
        }
        $updateFiles = array();
        foreach ($_FILES['file']['name'] as $fileName) {
            $fileNameNoExt = pathinfo($fileName)['filename'];//去除扩展名
            array_push($updateFiles, $fileNameNoExt);
        }
        $deleteFiles = array();
        foreach ($deleteGroup as $k => $v) {
            array_push($deleteFiles, $k);
        }

        //判断是否删除了当前更新的文件
        $intersect = array_intersect($updateFiles, $deleteFiles);
        if (count($intersect) > 0) {
            $this->error('删除了当前要更新的文件', '', 1);
            return;
        }

        $mainUpdateModel = new MainUpdateModel();
        $patchUpdateModel = new PatchUpdateModel();
        $patchFileModel = new PatchFilesModel();

        $mainVersion = $mainUpdateModel->LastEnableRelease()['version'];

        $lastPatchUpdate = $patchUpdateModel->LastPatchUpdate($mainVersion);
        $patchVersion = $lastPatchUpdate['patch_version'] + 1;


        $info = I('post.info', '', 'trim');
        $releaseState = I('post.releaseState', '', 'trim');
        $patchData['main_version'] = $mainVersion;
        $patchData['patch_version'] = $patchVersion;
        $patchData['info'] = $info;
        $patchData['release_state'] = $releaseState;

        $ret = $patchUpdateModel->add($patchData);
        if (!$ret) {
            $this->error($ret);
            return;
        }
        var_dump($ret);
        $patchID = $ret;

        $filesData = array();
        //处理上传文件
        if ($haveUploadFile) {
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize = 1073741824;// 设置附件上传大小
            $upload->rootPath = $this->PatchDir; // 设置附件上传根目录
            $upload->autoSub = false;
            $upload->saveExt = 'patch';
            // 上传文件
            $info = $upload->upload();
            if (!$info) {// 上传错误提示错误信息
                $this->error($upload->getError(), 3);
                return;
            } else {
                // 上传成功
                foreach ($info as $file) {
                    $fileName = pathinfo($file['name'])['filename'];//去除扩展名
                    $version = $patchFileModel->FindLastVersionOfFile($fileName)['version'] + 1;

                    $newName = $fileName . '-' . $version;
                    rename($this->PatchDir . $file['savename'], $this->PatchDir . $newName);
                    $data['file_name'] = $fileName;
                    $data['version'] = $version;
                    $data['patch_id'] = $patchID;
                    $data['to_delete'] = 0;
                    $data['file_location'] = $newName;
                    $data['md5'] = $file['md5'];
                    $data['size'] = filesize($this->PatchDir . $newName);
                    array_push($filesData, $data);
                }
            }
        }

        //处理删除文件
        if ($haveDeleteFile) {
            foreach ($deleteFiles as $fileName) {
                $version = $patchFileModel->FindLastVersionOfFile($fileName)['version'] + 1;
                $data['file_name'] = $fileName;
                $data['version'] = $version;
                $data['patch_id'] = $patchID;
                $data['to_delete'] = 1;
                $data['file_location'] = '';
                $data['md5'] = '';
                $data['size'] = '';
                array_push($filesData, $data);
            }
        }

        $ret = $patchFileModel->addAll($filesData);
        if (!$ret) {
            $this->error($ret);
            return;
        }
        $this->redirect('index');
    }

    public function show($mainVersion, $patchVersion)
    {
        $this->assign('mainVersion', $mainVersion);
        $this->assign('patchVersion', $patchVersion);

        $patchUpdateModel = new PatchUpdateModel();
        $where = array('main_version' => $mainVersion, 'patch_version' => $patchVersion);
        $data = $patchUpdateModel->where($where)->find();
        $this->assign('data', $data);

        $patchFilesModel = new PatchFilesModel();
        $fileData = $patchFilesModel->where(array('patch_id' => $data['id']))->select();

        $this->assign('fileData', $fileData);

        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);

        $this->assign('type', 'show');
        $this->display('show');
    }

    public function showUpdate($mainVersion, $patchVersion)
    {
        $this->assign('mainVersion', $mainVersion);
        $this->assign('patchVersion', $patchVersion);

        $patchUpdateModel = new PatchUpdateModel();
        $where = array('main_version' => $mainVersion, 'patch_version' => $patchVersion);
        $data = $patchUpdateModel->where($where)->find();
        $this->assign('data', $data);

        $patchFilesModel = new PatchFilesModel();
        $fileData = $patchFilesModel->where(array('patch_id' => $data['id']))->select();

        $this->assign('fileData', $fileData);

        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);

        $this->assign('type', 'update');
        $this->display('show');
    }

    public function update($mainVersion, $patchVersion)
    {
        $info = I('post.info', '', 'trim');
        $releaseState = I('post.releaseState', '', 'trim');

        $patchUpdateModel = new PatchUpdateModel();
        $where = array('main_version' => $mainVersion, 'patch_version' => $patchVersion);
        $data = $patchUpdateModel->where($where)->find();
        $data['info'] = $info;
        $data['release_state'] = $releaseState;

        $result = $patchUpdateModel->where($where)->setField($data);
        if ($result !== false) {
            $this->redirect('index');
        } else {
            $this->error($result);
        }
    }

    public function setEnable($mainVersion, $patchVersion, $enable)
    {
        $patchUpdateModel = new PatchUpdateModel();
        $where = array('main_version' => $mainVersion, 'patch_version' => $patchVersion);
        $patchUpdateModel->where($where)->setField('enable', $enable);
        $this->redirect('index');
    }


}