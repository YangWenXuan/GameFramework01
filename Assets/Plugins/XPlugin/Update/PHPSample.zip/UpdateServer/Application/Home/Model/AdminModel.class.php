<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-7-13
 * Time: 下午7:57
 */

namespace Home\Model;


use Think\Model;

class AdminModel extends Model
{
    public function Login($username, $password)
    {
        $result = $this->where(array("username" => $username, "password" => $password))->find();
        if ($result != null) {
            return $result;
        } else {
            return null;
        }
    }


}