<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-7-19
 * Time: 下午6:11
 */

namespace Home\Controller;


use Home\Model\MainUpdateModel;
use Home\Model\ReleaseStateModel;

class MainUpdateController extends BaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->assign('active', 'main');
        $this->assign('tab','update');
    }

    public function index()
    {
        $model = new MainUpdateModel();
        $updates = $model->FindWithLimit(200);

        $this->assign('updates', $updates);


        $this->display('index');
    }

    public function showAdd()
    {
        $mainUpdateModel = new MainUpdateModel();
        $lastRelease = $mainUpdateModel->LastRelease();
        $lastVersion = $lastRelease['version'];
        if ($lastVersion == null) {
            $lastVersion = 10000;
        }
        $data = array('version' => $lastVersion + 1);
        $this->assign('data', $data);

        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);

        $this->assign('type', 'add');
        $this->display('show');
    }

    public function show($version)
    {
        $mainUpdateModel = new MainUpdateModel();
        $data = $mainUpdateModel->FindByVersion($version);
        $this->assign('data', $data);

        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);

        $this->assign('type', 'show');
        $this->display('show');
    }

    public function showUpdate($version)
    {
        $mainUpdateModel = new MainUpdateModel();
        $data = $mainUpdateModel->FindByVersion($version);
        $this->assign('data', $data);

        $releaseState = new ReleaseStateModel();
        $allState = $releaseState->AllReleaseState();
        $this->assign('allState', $allState);

        $this->assign('type', 'update');
        $this->display('show');
    }


    public function setEnable($version, $enable)
    {
        $mainUpdateModel = new MainUpdateModel();
        $mainUpdateModel->where(array('version' => $version))->setField('enable', $enable);
        $this->redirect('index');
    }


    public function add()
    {
        $version = I('post.version', '', 'trim');
        $url = I('post.url', '', 'trim');
        $info = I('post.info', '', 'trim');
        $releaseState = I('post.releaseState', '', 'trim');

        $data['version'] = $version;
        $data['url'] = $url;
        $data['info'] = $info;
        $data['release_state'] = $releaseState;

        $mainUpdateModel = new MainUpdateModel();
        $result = $mainUpdateModel->add($data);
        if ($result) {
            $this->redirect('index');
        } else {
            echo 'error';
        }
    }

    public function update()
    {
        $version = I('post.version', '', 'trim');

        $url = I('post.url', '', 'trim');
        $info = I('post.info', '', 'trim');
        $releaseState = I('post.releaseState', '', 'trim');

        $mainUpdateModel = new MainUpdateModel();
        $data = $mainUpdateModel->where(array('version' => $version))->find();
        $data['url'] = $url;
        $data['info'] = $info;
        $data['release_state'] = $releaseState;

        $result = $mainUpdateModel->where(array('version' => $version))->setField($data);
        if ($result!==false) {
            $this->redirect('index');
        } else {
            $this->error($result);
        }
    }

}