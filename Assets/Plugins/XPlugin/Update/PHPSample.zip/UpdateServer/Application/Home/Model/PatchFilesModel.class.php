<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-6
 * Time: 下午8:06
 */

namespace Home\Model;


use Think\Model;

class PatchFilesModel extends Model
{

    public function SelectByPatchId($ids)
    {
        if(count($ids)>0){
            $map['patch_id'] = array('in', $ids);
            return $this->where($map)->select();
        }else{
            return null;
        }
    }

    public function FindLastVersionOfFile($fileName)
    {
        return $this->where(array('file_name' => $fileName))->order('version desc')->find();
    }


}