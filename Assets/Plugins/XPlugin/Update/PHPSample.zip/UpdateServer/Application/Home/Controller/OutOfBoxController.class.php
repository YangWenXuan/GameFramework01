<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-12
 * Time: 下午6:50
 */

namespace Home\Controller;


use Think\Controller;

class OutOfBoxController extends Controller
{
    public $conDir = 'Application/Common/Conf/';

    public function index()
    {
        if (!INIT) {
            $this->error('已经进行过开箱设置了，请检查' . $this->conDir . 'config.php');
            return;
        }
        $writable = file_put_contents($this->conDir . 'writable.tmp', 'test');
        $this->assign('writable', $writable);

        $url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER["REQUEST_URI"];
        $siteURL = substr($url,0,strrpos($url,'/index.php'));
        $this->assign('siteURL',$siteURL);

        $this->display();
    }

    public function start()
    {
        $db_address = I('post.db_address', '', 'trim');
        $db_port = I('post.db_port', '', 'trim');
        $db_user = I('post.db_user', '', 'trim');
        $db_pwd = I('post.db_pwd', '', 'trim');
        $db_name = I('post.db_name', '', 'trim');

        $site_name = I('post.site_name', '', 'trim');
        $site_url = I('post.site_url', '', 'trim');
        $admin_username = I('post.admin_username', '', 'trim');
        $admin_password = I('post.admin_pwd', '', 'trim');
        $admin_password_confirm = I('post.admin_pwd_confirm', '', 'trim');

        if ($admin_password != $admin_password_confirm) {
            $this->error('密码与确认密码不匹配', '', 1);
            return;
        }

        $conn = mysql_connect($db_address . ':' . $db_port, $db_user, $db_pwd);
        if (!$conn) {
            $this->error('无法连接到数据库', '', 3);
            return;
        }

        $sql = 'CREATE DATABASE ' . $db_name;
        if (!mysql_query($sql, $conn)) {
            $this->error('无法创建数据库:' . mysql_error());
            return;
        }

        $sql = 'use ' . $db_name;
        if (!mysql_query($sql, $conn)) {
            $this->error('无法使用数据库:' . mysql_error());
            return;
        }

        $sql = file_get_contents($this->conDir . 'init_mysql.sql');
        $sq = explode(";\n", $sql);
        foreach ($sq as $s) {
            if (trim($s) != '') {
                if (!mysql_query($s, $conn)) {
                    $this->error('执行SQL语句出错:' . mysql_error());
                    return;
                }
            }
        }
        $sql = "INSERT INTO admin (username,password)
                VALUES ('" . $admin_username . "','" . $admin_password . "')";
        if (!mysql_query($sql, $conn)) {
            $this->error('插入管理员数据出错:' . mysql_error(), '', 100);
            return;
        }

        file_put_contents($this->conDir . 'config.php', ' <?php
define(\'INIT\',\'' . false . '\');
define(\'SITE_NAME\',\'' . $site_name . '\');
define(\'SITE_URL\',\'' . $site_url . '\');

return array(
    //数据库配置信息
    \'DB_TYPE\'   => \'mysql\', // 数据库类型
    \'DB_HOST\'   => \'' . $db_address . '\', // 服务器地址
    \'DB_PORT\'   => ' . $db_port . ', // 端口
    \'DB_USER\'   => \'' . $db_user . '\', // 用户名
    \'DB_PWD\'    => \'' . $db_pwd . '\', // 密码
    \'DB_NAME\'   => \'' . $db_name . '\', // 数据库名

    \'DEFAULT_MODULE\'        =>  \'Home\',            // 默认模块
    \'DEFAULT_CONTROLLER\'    =>  \'login\',            // 默认控制器名称
    \'DEFAULT_ACTION\'        =>  \'index\',            // 默认操作名称
);');

        $this->redirect('Login/index');
    }

}