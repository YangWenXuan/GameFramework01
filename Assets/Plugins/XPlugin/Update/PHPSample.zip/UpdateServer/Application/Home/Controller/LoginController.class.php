<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-7-12
 * Time: 下午7:52
 */

namespace Home\Controller;


use Home\Model\AdminModel;
use Think\Controller;

class LoginController extends Controller
{

    public function __construct(){
        parent::__construct();
        if(INIT){
            $this->redirect('OutOfBox/index');
            return;
        }
        $this->assign('site_name',SITE_NAME);
    }

    public function index()
    {
        $this->display();
    }

    public function  login()
    {
        $username = I('post.username', '', 'trim');
        $password = I('post.password', '', 'trim');

        $model=new AdminModel();
        $result = $model->Login($username, $password);
        if ($result != null) {
            session('admin', $result);
            $this->redirect('Index/index');
        } else {
            $this->error('用户名或密码错误', 'index', 1);
        }
    }

    public function logout()
    {
        session('admin', null);
        $this->redirect('Login/index');
    }
}