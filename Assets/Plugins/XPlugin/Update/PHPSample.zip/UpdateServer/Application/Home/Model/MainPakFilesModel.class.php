<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-12
 * Time: 下午4:29
 */

namespace Home\Model;


use Think\Model;

class MainPakFilesModel extends Model
{


}