<?php
/**
 * Created by PhpStorm.
 * User: l
 * Date: 15-9-4
 * Time: 下午9:21
 */

namespace Home\Model;


use Think\Model;

class MainUpdateModel extends Model
{

    public function FindWithLimit($limit)
    {
        $result = $this->order('version desc')->limit($limit)->select();
        return $result;
    }

    public function LastEnableRelease()
    {
        $result = $this->where(array('enable' => true))->order('version desc')->find();
        return $result;
    }

    public function LastRelease()
    {
        $result = $this->order('version desc')->find();
        return $result;
    }

    public function FindByVersion($version)
    {
        $result = $this->where(array('version' => $version))->find();
        return $result;
    }

    public function LastEnableReleaseWithPerm($permission)
    {

        $releaseStateMode = new ReleaseStateModel();
        $permission = $releaseStateMode->GetPermission($permission);

        $where['enable'] = true;
        $where['permission'] = array('elt', $permission);

        return $this->join('release_state on main_update.release_state=release_state.name')
            ->where($where)->order('version desc')->find();
    }


}