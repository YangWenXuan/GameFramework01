CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(36) NOT NULL,
  `password` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `main_pak_files` (
  `file_name` varchar(200) NOT NULL,
  `file_location` varchar(300) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `main_update` (
  `version` mediumint(9) NOT NULL,
  `url` varchar(500) NOT NULL,
  `info` text,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `release_state` varchar(100) NOT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `patch_files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `version` int(11) NOT NULL,
  `patch_id` int(11) NOT NULL,
  `to_delete` tinyint(1) NOT NULL DEFAULT '0',
  `file_location` varchar(300) DEFAULT NULL,
  `md5` varchar(100) DEFAULT NULL,
  `size` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `patch_update` (
  `id` int(11) NOT NULL,
  `main_version` int(11) NOT NULL,
  `patch_version` int(11) NOT NULL,
  `info` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `release_state` varchar(100) NOT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `permission` (
  `user` varchar(200) NOT NULL,
  `permission` varchar(100) NOT NULL,
  `description` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `release_state` (
  `name` varchar(100) NOT NULL,
  `permission` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `admin`
ADD PRIMARY KEY (`username`), ADD KEY `username` (`username`);

ALTER TABLE `main_pak_files`
ADD PRIMARY KEY (`file_name`);

ALTER TABLE `main_update`
ADD PRIMARY KEY (`version`), ADD KEY `release_state` (`release_state`), ADD KEY `enable` (`enable`);

ALTER TABLE `patch_files`
ADD PRIMARY KEY (`id`), ADD KEY `patch_id` (`patch_id`);

ALTER TABLE `patch_update`
ADD PRIMARY KEY (`id`), ADD KEY `main_version` (`main_version`), ADD KEY `patch_version` (`patch_version`), ADD KEY `enable` (`enable`);

ALTER TABLE `permission`
ADD PRIMARY KEY (`user`);

ALTER TABLE `release_state`
ADD PRIMARY KEY (`name`);

ALTER TABLE `patch_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `patch_update`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

INSERT INTO `release_state` (`name`, `permission`) VALUES
  ('ALPHA', 100),
  ('BETA', 70),
  ('RC', 30),
  ('RTM', 0);

