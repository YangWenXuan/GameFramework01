 <?php
define('INIT','');
define('SITE_NAME','XXX 更新后台');
define('SITE_URL','http://127.0.0.1/UpdateServer');

return array(
    //数据库配置信息
    'DB_TYPE'   => 'mysql', // 数据库类型
    'DB_HOST'   => '127.0.0.1', // 服务器地址
    'DB_PORT'   => 3306, // 端口
    'DB_USER'   => 'root', // 用户名
    'DB_PWD'    => 'root', // 密码
    'DB_NAME'   => 'test_update', // 数据库名

    'DEFAULT_MODULE'        =>  'Home',            // 默认模块
    'DEFAULT_CONTROLLER'    =>  'login',            // 默认控制器名称
    'DEFAULT_ACTION'        =>  'index',            // 默认操作名称
);